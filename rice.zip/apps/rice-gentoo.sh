#!/bin/bash

set -e

if [ "$EUID" -ne 0 ]
  then echo "The script has to be run as root."
  exit
fi

BIN_DIR=${BIN_DIR:-/usr/local/bin/}

pwd=$(pwd)
cd ..
cd ..
userhome=$(pwd)
cd $pwd

checkinstdir() {
if [ -d $1 ]; then
	echo "$1 ok"
else
	echo "$1 is missing"
	exit -1
fi
}

echo "Checking directories"
checkinstdir $BIN_DIR

echo "creating rice directory for root"
mkdir $HOME/.config

echo "Adding Dots to root home"
cp dots/.rootbashrc /$HOME/.bashrc
cp dots/.vimrc $HOME
cp dots/.xinitrc $HOME
cp dots/.Xresources $HOME
chmod +x dots/.setres.sh
cp dots/.setres.sh $HOME

echo "Adding Dots to user home"
cp dots/.bashrc $userhome
cp dots/.vimrc $userhome
cp dots/.xinitrc $userhome
cp dots/.Xresources $userhome
chmod +x dots/.setres.sh
cp dots/.setres.sh $userhome

cp -r dwm $HOME/.config
cp -r dmenu $HOME/.config
cp -r slstatus $HOME/.config
cp -r st $HOME/.config

cd $HOME/.config/dwm
make clean install
echo "installed dwm"
cd $HOME/.config/dmenu
make clean install
echo "installed dmenu"
cd $HOME/.config/slstatus
make clean install
echo "installed slstatus"
cd $HOME/.config/st
make clean install
echo "installed st"

cmod +x $HOME/gentootestscript-master/finalize.sh
sh $HOME/gentootestscript-master/finalize.sh
echo "xorg can now be run as a non root user, and ALSA works now"

fc-cache -fv

echo "Install finished. Add software to .xinitrc to launch the DE with startx,
or copy the provided .xinitrc file to your home directory (backup the old one!)"
